// ==UserScript==
// @name         Endymion V3.0.2 Lite — Self Hosted + Local #1 Tracker
// @namespace    https://github.com/mohammadalrisheq/idk-what-is-this
// @version      3.0.2
// @description  Stable Endymion dual-cell + ws3 standby/promotion build, without Team Vision, with a relay-independent #1 minimap tracker.
// @author       Project contributors
// @match        https://3rb.io/*
// @match        https://*.3rb.io/*
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// @connect      mohammadalrisheq.github.io
// ==/UserScript==

(() => {
  "use strict";

  const BASE_URL = "https://mohammadalrisheq.github.io/idk-what-is-this/";
  const FILES = Object.freeze({ page: "index.html", scripts: ["v.js", "m.js"] });

  const makeUrl = file => {
    const url = new URL(file, BASE_URL.endsWith("/") ? BASE_URL : `${BASE_URL}/`);
    url.searchParams.set("endymion_build", "3.0.2-lite-top1");
    url.searchParams.set("endymion_cache", `${Date.now()}`);
    return url.href;
  };

  const requestText = file => new Promise((resolve, reject) => {
    const url = makeUrl(file);
    GM_xmlhttpRequest({
      method: "GET",
      url,
      headers: { "Cache-Control": "no-cache, no-store, must-revalidate", Pragma: "no-cache" },
      timeout: 30000,
      onload: ({ status, responseText }) => {
        if (status < 200 || status >= 300 || !responseText) return reject(new Error(`${file} returned HTTP ${status || "unknown"}`));
        resolve({ file, url, source: responseText });
      },
      onerror: () => reject(new Error(`Network failure while loading ${file}`)),
      ontimeout: () => reject(new Error(`Timed out while loading ${file}`)),
    });
  });

  const replaceDocument = html => {
    document.open();
    document.write(html);
    document.close();
  };

  const showBootstrap = () => replaceDocument(`<!doctype html><html><head><meta charset="utf-8"><title>Endymion</title></head>
    <body style="margin:0;background:#08070b;color:#eee;font:16px system-ui;display:grid;place-items:center;height:100vh">
      <div style="text-align:center"><div style="font-size:30px;letter-spacing:.15em">ENDYMION</div>
      <div style="margin-top:12px;opacity:.72">Loading stable Lite build...</div></div></body></html>`);

  const showFailure = error => replaceDocument(`<!doctype html><html><head><meta charset="utf-8"><title>Endymion failed</title></head>
    <body style="margin:0;background:#0b080d;color:#ff87c8;font:15px ui-monospace,monospace;padding:36px">
      <h2>Endymion failed to start</h2><pre style="white-space:pre-wrap;color:#fff">${String(error?.stack || error).replace(/[&<>]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;"})[c])}</pre>
      <p>Base URL: ${BASE_URL}</p><button onclick="location.reload()" style="padding:10px 16px">Reload</button></body></html>`);

  const execute = ({ file, url, source }) => {
    const wrapped = `${source}\n//# sourceURL=${url.replace(/[\r\n]/g, "")}`;
    try { new Function(wrapped)(); }
    catch (error) { error.message = `${file}: ${error.message}`; throw error; }
  };

  const waitForDocument = () => new Promise(resolve => {
    if (document.readyState !== "loading") return resolve();
    let finished = false;
    const finish = () => { if (!finished) { finished = true; resolve(); } };
    document.addEventListener("DOMContentLoaded", finish, { once: true });
    setTimeout(finish, 10000);
  });

  const start = async () => {
    showBootstrap();
    try {
      const [page, ...scripts] = await Promise.all([requestText(FILES.page), ...FILES.scripts.map(requestText)]);
      replaceDocument(page.source);
      await waitForDocument();
      for (const script of scripts) execute(script);
    } catch (error) {
      console.error("[Endymion] Startup failed", error);
      showFailure(error);
    }
  };

  start();
})();
