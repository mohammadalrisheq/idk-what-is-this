ENDYMION V3.0.2 LITE — STABLE CORE + LOCAL #1 TRACKER

THIS BUILD IS BASED ON THE WORKING V3.0.1 STABLE TEAM-UNION ZIP, BUT THE
ENTIRE TEAM VISION / TEAM UNION MODULE HAS BEEN REMOVED.

KEPT:
- Tab 1 and Tab 2 playable sessions
- ws3 authenticated hot standby
- ws3 promotion after death/disconnection
- K, /kill and /recycle manual promotion
- Auto-respawn toggle
- Continue-movement toggle
- Dual nicknames and dual skins
- Existing Tag Players list and normal teammate minimap dots
- Original stable Endymion UI

NEW:
- ws3 tracks the ordinary server-provided #1 spectator position while idle
- Direct local #1 marker on the existing small bottom-right minimap
- Marker updates from live opcode-17 packets; no Team Vision relay is involved
- ws3 map border is captured separately for accurate normalized positioning
- F7 immediately refreshes the #1 spectator request
- Menu button can turn the #1 tracker on/off
- ws3 still yields to the existing promotion system when a playable tab dies

REMOVED:
- Full Team Union map
- Remote enemy sharing
- Remote ghost/radar overlays
- Team Vision settings and relay
- F8 Team Union map

FASTEST TEST:
1. Disable every other full Endymion/NyxDarkness userscript.
2. Install 1-INSTALL-FIRST/Endymion-V3.0.2-Lite-Bundled.user.js.
3. Open a fresh beta.3rb.io tab.

SELF-HOSTED:
1. Upload index.html, m.js and v.js from 3-GITHUB-ROOT-FILES to the repository root.
2. Install 2-SELF-HOSTED/Endymion-V3.0.2-Lite-SelfHosted.user.js.
3. Do not enable bundled and self-hosted versions together.

CONSOLE CHECKS:
ENDYMION_BUILD
ENDYMION_TOP1.snapshot()
ENDYMION_TOP1.reconnect()
ENDYMION_TOP1.setEnabled(false)
DARK_ENDYMION.status()
DARK_ENDYMION.ws3()

EXPECTED BUILD MARKER:
ENDYMION-V3.0.2-LITE-LOCAL-TOP1-WS3-STANDBY
